<?php header('Content-Type: text/html; charset=utf-8'); ?>
<!doctype html><html><head><meta charset="utf-8"><title>About</title></head><body>
<div class="container">
<h2>About</h2>
<p>Aplikasi ini dibuat untuk keperluan praktikum System Testing. Ganti placeholder API key di index.php dengan kunci NewsAPI Anda.</p>
<p>Created by Putri Kartika Natasya</p>
</div></body></html>
