<?php
// index.php - API key placed here (placeholder)
$apiKey = "fc5bb4c21b8e4d96810198088ba7d5aa"; 
$category = isset($_GET['category']) ? $_GET['category'] : "technology";
$action = isset($_GET['action']) ? $_GET['action'] : '';
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>News - Uji_hasil_pencarian_berita_technology</title>
<link rel="stylesheet" href="css/styles.css">
</head>
<body>
<div class="container">
  <div class="header">
    <h1>News Demo - Uji_hasil_pencarian_berita_technology</h1>
    <p>Menampilkan berita dari NewsAPI (kategori: <strong><?php echo htmlspecialchars($category); ?></strong>)</p>
  </div>
  <form method="get" class="search-bar">
    <label for="category">Pilih kategori:</label>
    <select id="category" name="category" class="select">
      <option value="general"<?php if($category=='general') echo ' selected';?>>general</option>
      <option value="business"<?php if($category=='business') echo ' selected';?>>business</option>
      <option value="technology"<?php if($category=='technology') echo ' selected';?>>technology</option>
      <option value="sports"<?php if($category=='sports') echo ' selected';?>>sports</option>
    </select>
    <input type="hidden" name="action" value="view">
    <button type="submit" class="btn">Lihat Berita</button>
  </form>

<?php
if($action == 'view') {
    // Bangun URL ke NewsAPI
    $url = 'https://newsapi.org/v2/top-headlines?country=us&category=' . urlencode($category) . '&apiKey=' . urlencode($apiKey);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('User-Agent: SystemTestingPraktikum/1.0'));
    $resp = curl_exec($ch);
    $err = curl_error($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if($err) {
        echo '<p><strong>Error:</strong> ' . htmlspecialchars($err) . '</p>';
    } else {
        $data = json_decode($resp, true);
        if(!$data) {
            echo '<p>Response tidak valid atau kosong.</p>';
        } else if(isset($data['status']) && $data['status'] === 'error') {
            echo '<p><strong>API Error:</strong> ' . htmlspecialchars($data['message']) . '</p>';
        } else if(isset($data['articles']) && count($data['articles'])>0) {
            echo '<div class="articles">';
            foreach($data['articles'] as $a) {
                $title = isset($a['title']) ? $a['title'] : '(No title)';
                $source = isset($a['source']['name']) ? $a['source']['name'] : '(Unknown)';
                $date = isset($a['publishedAt']) ? date('d M Y H:i', strtotime($a['publishedAt'])) : '-';
                $img = isset($a['urlToImage']) && $a['urlToImage'] ? $a['urlToImage'] : 'placeholder.png';
                $url = isset($a['url']) ? $a['url'] : '#';
                echo '<div class="card">';
                echo '<img src="' . htmlspecialchars($img) . '" alt="thumb">';
                echo '<div class="card-body">';
                echo '<div class="card-title">' . htmlspecialchars($title) . '</div>';
                echo '<div class="card-meta">' . htmlspecialchars($source) . ' &middot; ' . htmlspecialchars($date) . '</div>';
                echo '<a class="btn" href="' . htmlspecialchars($url) . '" target="_blank">Baca Selengkapnya</a>';
                echo '</div></div>';
            }
            echo '</div>';
        } else {
            echo '<p>Tidak ditemukan artikel untuk kategori ini.</p>';
        }
    }
}
?>

<div class="footer">Created by Putri Kartika Natasya</div>
</div>
</body>
</html>
