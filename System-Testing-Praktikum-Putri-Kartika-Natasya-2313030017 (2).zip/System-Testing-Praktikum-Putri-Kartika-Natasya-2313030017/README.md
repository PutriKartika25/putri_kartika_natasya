System Testing - Praktikum (Final)

Project by: Putri Kartika Natasya (2313030017) - Kelas 3A

Petunjuk singkat:
1. Ekstrak folder ini ke C:\xampp\htdocs\
2. Di setiap folder Black_Box (Uji_...), buka file index.php dan ganti nilai $apiKey dengan API key NewsAPI Anda.
   Contoh: $apiKey = "fc5bb4c21b8e4d96810198088ba7d5aa";
3. Jalankan Apache di XAMPP dan akses URL contoh:
   http://localhost/System-Testing-Praktikum-Putri-Kartika-Natasya-2313030017/Black_Box/Uji_koneksi_API_valid/index.php
4. Folder White_Box berisi system-test.php untuk pengujian white-box sederhana.
