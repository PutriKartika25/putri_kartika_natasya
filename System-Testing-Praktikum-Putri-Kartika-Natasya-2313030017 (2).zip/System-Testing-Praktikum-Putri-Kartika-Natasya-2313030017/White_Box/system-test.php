<?php
// White box test script: simple cURL checks
function http_request_get($url) {
    try {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('User-Agent: SystemTestingPraktikum/1.0'));
        $output = curl_exec($ch);
        if (curl_errno($ch)) {
            throw new Exception('Curl Error: ' . curl_error($ch));
        }
        $status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($status_code !== 200) {
            throw new Exception('Status code tidak 200: ' . $status_code);
        }
        return $output;
    } catch (Exception $e) {
        return 'FAIL - ' . $e->getMessage();
    }
}

echo "<h2>White Box - System Test</h2>";
echo "<p>TC-001: Endpoint valid (https://newsapi.org/v2/top-headlines?country=us&q=naruto)</p>";
$r1 = http_request_get('https://newsapi.org/v2/top-headlines?country=us&q=naruto');
if (strpos($r1, 'articles') !== false) { echo '<p>Hasil: PASS</p>'; } else { echo '<p>Hasil: ' . htmlspecialchars($r1) . '</p>'; }

echo "<p>TC-002: Endpoint salah (https://newsapi.org/v2/top-headlines-invalid)</p>";
$r2 = http_request_get('https://newsapi.org/v2/top-headlines-invalid');
if (strpos($r2, 'FAIL') !== false) { echo '<p>Hasil: ' . htmlspecialchars($r2) . '</p>'; } else { echo '<p>Hasil: FAIL (Seharusnya gagal)</p>'; }

echo "<p>TC-003: Domain salah (https://invalid.newsapi.org/v2)</p>";
$r3 = http_request_get('https://invalid.newsapi.org/v2');
if (strpos($r3, 'FAIL') !== false) { echo '<p>Hasil: ' . htmlspecialchars($r3) . '</p>'; } else { echo '<p>Hasil: FAIL (Seharusnya gagal)</p>'; }
?>
