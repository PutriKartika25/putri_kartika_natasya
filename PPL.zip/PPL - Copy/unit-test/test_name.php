<?php
require_once 'validator.php';
$validator = new validator();

$test_cases = [
    "PUTRI KARTIKA NATASYA", //valid
    "1212", //tidak valid (angka)
    "", //tidak valid (kosong)
    "Putri123", //tidak valid (campuran huruf dan angka)
    " " //idak valid (hanya spasi)
];

echo "<h2> Skenario Testing: Validasi Input Nama Mahasiswa</h2>";
echo "<table border='1' cellpadding='8' cellspacing='0'>";
echo "<tr><th>No</th><th>INPUT NAMA</th><th><HASIL VALIDASI></th></tr>";

$no = 1;
foreach ($test_cases as $case) {
    $result = $validator->validateName($case);
    echo "<tr>";
    echo "<td>{$no}</td>";
    echo "<td>" . ($case === "" ? "(kosong)" : htmlspecialchars($case)). "</td>";
    echo "<td>{$result}</td>";
    echo "</tr>";
    $no++;
}

echo "</table>";
?>