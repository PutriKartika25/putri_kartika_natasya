<?php
class validator {
// Fungsi validasi nama mahasiswa
public function validateName($name) {
    // 1 Nama tidak boleh kosong
    if(empty(trim($name))){
        return "Error: Nama tidak boleh kosong.";
    }
    // 2 Nama harus berupa huruf dan spasi
    if (!preg_match("/^[a-zA-Z\s]+$/", $name)) {
        return "Error : Nama harus berupa huruf saja.";
    }
    // 3 Jika valid
    return "valid: Nama diterima.";
}
}
?>