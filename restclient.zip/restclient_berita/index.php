<?php
// Load konfigurasi cURL
include("config/config.php");

// API Key dari NewsAPI.org
$api_key = "fc5bb4c21b8e4d96810198088ba7d5aa";

// URL endpoint untuk headline berita Indonesia
$url = "https://newsapi.org/v2/top-headlines?country=id&apiKey=" . $api_key;

// Ambil data menggunakan fungsi http_request_get()
$data = http_request_get($url);

// Ubah hasil JSON menjadi array PHP
$hasil = json_decode($data, true);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Rest Client Berita Indonesia</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-info">
  <a class="navbar-brand" href="#">RestClient</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active"><a class="nav-link" href="#">Home</a></li>
      <li class="nav-item"><a class="nav-link" href="#">News</a></li>
      <li class="nav-item"><a class="nav-link" href="#">About</a></li>
    </ul>
  </div>
</nav>
<!-- /Navbar -->

<div class="container" style="margin-top: 80px;">
  <div class="row">
    <?php
    // Pastikan hasil API valid
    if (isset($hasil['articles']) && count($hasil['articles']) > 0) {
        foreach ($hasil['articles'] as $row) {
            $judul = htmlspecialchars($row['title'] ?? 'Tidak ada judul');
            $penulis = htmlspecialchars($row['author'] ?? 'Anonim');
            $gambar = $row['urlToImage'] ?? 'https://via.placeholder.com/300x180?text=No+Image';
            $link = $row['url'] ?? '#';
            echo '
            <div class="col-md-3 mb-4">
                <div class="card h-100 shadow-sm">
                    <img src="' . $gambar . '" class="card-img-top" height="180px" alt="Berita">
                    <div class="card-body">
                        <h6 class="card-title">' . $judul . '</h6>
                        <p class="text-muted"><small><i>Oleh ' . $penulis . '</i></small></p>
                        <a href="' . $link . '" target="_blank" class="btn btn-sm btn-primary">Selengkapnya</a>
                    </div>
                </div>
            </div>';
        }
    } else {
        echo '<div class="col-md-12"><div class="alert alert-warning">Tidak ada berita yang bisa ditampilkan.</div></div>';
    }
    ?>
  </div>
</div>

<script src="js/jquery-3.4.1.slim.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
