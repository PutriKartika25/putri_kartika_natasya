<?php
/**
 * File: config/config.php
 * Deskripsi: Fungsi helper untuk mengambil data API menggunakan cURL
 */

function http_request_get($url) {
    // Inisialisasi cURL
    $ch = curl_init();

    // Set opsi cURL
    curl_setopt($ch, CURLOPT_URL, $url);                 // URL target
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);      // Kembalikan hasil ke variabel
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);      // Ikuti redirect (jika ada)
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);               // Timeout maksimal 20 detik
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);     // Nonaktifkan verifikasi SSL (untuk localhost)
    curl_setopt($ch, CURLOPT_USERAGENT, 
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    );

    // Eksekusi dan simpan hasilnya
    $output = curl_exec($ch);

    // Cek jika terjadi error
    if (curl_errno($ch)) {
        echo "cURL Error: " . curl_error($ch);
        $output = null;
    }

    // Tutup koneksi cURL
    curl_close($ch);

    // Kembalikan hasil
    return $output;
}
?>
